Hello to run the app need:

*******    for jar file   At   Directory "Java backend developer assignment\JAVA Email Server\json\jar"   remove .txt  extintion  because Gmail not sending jar file   *****  
1
- import  "JAVA Email Server"   on eclipse or another  program for developing applications in java.

2- import  "Email Client emulator"   on eclipse or another  program for developing applications in java .

3- run main function in  "JAVA Email Server" in class "MyServer"

4- run main function in "Email Client emulator" in class "ClientUI"

"if the app did't run because of port try yo change it in  PORT.txt  ,important to be the same in PORT file in client and server files"

5- insert data in the client UI.


6- see results in  JAVA Email Server Console .

